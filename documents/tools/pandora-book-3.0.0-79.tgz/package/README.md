# Pandora CLI

## Dev testing

In the root folder, run the build script.

```bash
npm run build
```
You should the have the pandora command linked to your global npm modules.

```bash
pandora --help
```

## Installation

```bash
npm i -g pandora-book@next
```
