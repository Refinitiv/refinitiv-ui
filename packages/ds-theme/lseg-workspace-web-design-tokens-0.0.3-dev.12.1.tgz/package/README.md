# LSEG Workspace Components : Web Design Tokens

Design token toolchain for LSEG Workspace components.

## Installation

```sh
npm install @lseg-workspace/web-design-tokens
```

## Contributing and setting up development

See [CONTRIBUTING.md](../../CONTRIBUTING.md)
