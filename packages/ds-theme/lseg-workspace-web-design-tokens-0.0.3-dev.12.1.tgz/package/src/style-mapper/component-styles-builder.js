const isPositionToken = (tokenName) => tokenName.includes('position-inset');
const isBlurToken = (tokenName) => tokenName.includes('bg-blur');
const isTransformRotateToken = (tokenName) => tokenName.includes('transform-rotate');

/**
 * Handles custom transformations for CSS properties based on conditions defined in the name.
 *
 * @param {string} tokenName - The token name to check for custom conditions.
 * @param {string|Array} cssProperty - The CSS property or properties to process.
 * @param {string} value - The value of the CSS property.
 * @returns {Array} Array of transformed CSS properties and their values.
 */
export function handleCustomCSSTransformations(tokenName, cssProperty, value) {
  if (isPositionToken(tokenName)) {
    return [
      { property: 'position', transformedValue: 'absolute' },
      { property: cssProperty, transformedValue: value },
    ];
  }

  const properties = Array.isArray(cssProperty) ? cssProperty : [cssProperty];

  return properties.map((property) => {
    let transformedValue = value;

    if (isBlurToken(tokenName)) {
      transformedValue = `blur(${value})`;
    } else if (isTransformRotateToken(tokenName)) {
      transformedValue = `rotate(${value})`;
    }

    return { property, transformedValue };
  });
}

/**
 * Generate a full CSS selector string based on base selector, classes, and pseudo-class.
 *
 * @param {Object} metadata - The component metadata object.
 * @param {string} baseSelector - The base CSS selector.
 * @param {Object} selectorMapping - The mapping object to transform metadata into CSS selectors.
 * @returns {string} The full CSS selector.
 */
export function generateFullSelector(metadata, baseSelector, selectorMapping) {
  const {
    classes,
    attributes = [],
    pseudoClass,
    hostSelectorScopes,
  } = applySelectorMappingToMetadata(metadata, selectorMapping);

  // Helper functions for generating selectors
  const generateClassSelectors = (classes) => classes && classes.map((cls) => `.${cls}`).join('');

  const generateAttributeSelectors = (attributes) =>
    attributes && attributes.map((atr) => `[${atr}]`).join('');

  const generateHostSelector = (hostSelectorScopes) => {
    const { classes = [], attributes = [], pseudoClass } = hostSelectorScopes;

    const classSelectors = generateClassSelectors(classes);
    const attributeSelectors = generateAttributeSelectors(attributes);
    const pseudoClassSelector = pseudoClass ? `:${pseudoClass}` : '';

    return attributes.length || classes.length || pseudoClass
      ? `:host(${attributeSelectors}${classSelectors}${pseudoClassSelector})`
      : '';
  };

  const classSelectors = generateClassSelectors(classes);
  const attributeSelectors = generateAttributeSelectors(attributes);
  const pseudoClassSelector = pseudoClass ? `:${pseudoClass}` : '';
  const hostSelector = hostSelectorScopes ? generateHostSelector(hostSelectorScopes) : '';

  const generatedSelector = `${attributeSelectors}${classSelectors}${pseudoClassSelector}`;
  const updatedBaseSelector = baseSelector.includes('{selector}')
    ? baseSelector.replace(/{selector}/g, generatedSelector)
    : `${baseSelector}${generatedSelector}`;

  return `${hostSelector} ${updatedBaseSelector}`.trim();
}

/**
 * Update metadata based on selector mapping to determine CSS selector components.
 *
 * @param {Object} metadata - The component metadata object.
 * @param {Object} selectorMapping - The mapping object used to transform metadata.
 * @returns {Object} The updated metadata including transformed selector components.
 */
export function applySelectorMappingToMetadata(metadata, selectorMapping = {}) {
  let classes = metadata.classes;
  let pseudoClass = metadata.pseudoClass;
  const attributes = [];
  const hostSelectorScopes = {
    classes: [],
    attributes: [],
    pseudoClass: '',
  };

  if (Object.keys(selectorMapping).length === 0) {
    return metadata;
  }

  Object.entries(selectorMapping).forEach(([key, { type, scope }]) => {
    const isClassMatched = metadata.classes.includes(key);
    const isPseudoClassMatched = metadata.pseudoClass === key;

    if (!isClassMatched && !isPseudoClassMatched) {
      return;
    }

    if (isClassMatched) {
      classes = classes.filter((cl) => cl !== key);
    } else if (isPseudoClassMatched) {
      pseudoClass = '';
    }

    switch (type) {
      case 'attribute':
        if (scope === 'host') {
          hostSelectorScopes.attributes.push(key);
        } else {
          attributes.push(key);
        }
        break;

      case 'class':
        if (scope === 'host') {
          classes = classes.filter((cl) => cl !== key);
          hostSelectorScopes.classes.push(key);
        } else {
          classes.push(key);
        }
        break;

      case 'pseudoClass':
        if (scope === 'host') {
          hostSelectorScopes.pseudoClass = key;
          pseudoClass = '';
        } else {
          pseudoClass = key;
        }
        break;

      default:
        break;
    }
  });

  return {
    ...metadata,
    classes,
    pseudoClass,
    attributes,
    hostSelectorScopes,
  };
}

/**
 * Maps component metadata to CSS selectors based on the provided mapping.
 *
 * @param {Object} metadata - The component metadata object.
 * @param {Object} mapping - The mapping object to transform metadata into CSS selectors.
 * @returns {Object} The mapped CSS data, where keys are CSS selectors and values are objects with CSS properties.
 *
 * @example
 * Metadata: { token-1: { part: 'container', classes: ['sm'], ... }, token-2: { part: 'container', classes: ['md'] ... } }
 * Mapping: { partsMapping: [{ selectors: '.my-container', parts: 'container' }], selectorMapping: {} }
 * Output: { '.my-container.sm': { 'cssProperty': 'value' }, '.my-container.md': { 'cssProperty': 'value' } }
 */
export function mapMetadataToSelectors(metadata, mapping) {
  const { partsMapping, selectorMapping } = mapping;
  const mappedStyles = {};

  partsMapping.forEach((partMapping) => {
    partMapping.parts.forEach((partKey) => {
      let matchedPartStyles = Object.values(metadata);

      if (partKey !== '*') {
        matchedPartStyles = matchedPartStyles.filter(
          (metaItem) => metaItem.part === partKey || partKey === metaItem.name
        );
      }

      // Process each matched part to build CSS selectors and properties
      matchedPartStyles.forEach((matchedMetadata) => {
        partMapping.selectors.forEach((selector) => {
          const fullSelector = generateFullSelector(matchedMetadata, selector, selectorMapping);

          if (!mappedStyles[fullSelector]) {
            mappedStyles[fullSelector] = {};
          }

          const transformedProperties = handleCustomCSSTransformations(
            matchedMetadata.name,
            matchedMetadata.cssProperty,
            matchedMetadata.value
          );

          transformedProperties.forEach(({ property, transformedValue }) => {
            mappedStyles[fullSelector][property] = transformedValue;
          });
        });
      });
    });
  });

  return mappedStyles;
}

/**
 * Merges CSS rules with identical properties into a single rule with combined selectors.
 *
 * @param {Object} styles - An object where keys are CSS selectors and values are objects with CSS properties.
 * @returns {Object} An object where keys are combined CSS selectors and values are objects with merged CSS properties.
 *
 * @example
 * Input: { '.button': { 'color': 'red' }, '.btn': { 'color': 'red' } }
 * Output: { '.button, .btn': { 'color': 'red' } }
 */
export function mergeCSSRules(styles) {
  const propertyToSelectorsMap = {};

  // Group selectors by their property set
  Object.entries(styles).forEach(([selector, properties]) => {
    const propertiesKey = JSON.stringify(properties);
    if (!propertyToSelectorsMap[propertiesKey]) {
      propertyToSelectorsMap[propertiesKey] = [];
    }
    propertyToSelectorsMap[propertiesKey].push(selector);
  });

  // Convert grouped selectors into merged CSS rules
  return Object.entries(propertyToSelectorsMap).reduce((acc, [propertiesKey, selectors]) => {
    const properties = JSON.parse(propertiesKey);
    acc[selectors.join(', ')] = properties;
    return acc;
  }, {});
}

/**
 * Converts a JavaScript object representing CSS styles into a CSS string.
 *
 * @param {Object} styles - An object where keys are CSS selectors and values are objects with CSS properties.
 * @returns {string} The generated CSS string.
 *
 * @example
 * Input: { .button: { 'color': 'red' }, .container: { 'margin': '10px' } }
 * Output: ".button { color: red; } .container { margin: 10px; }"
 */
export function generateCSSString(styles) {
  return Object.entries(styles)
    .filter(([, properties]) => Object.keys(properties).length > 0)
    .map(
      ([selectors, properties]) =>
        `${selectors} {\n${Object.entries(properties)
          .map(([property, value]) => `  ${property}: ${value};`)
          .join('\n')}\n}`
    )
    .join('\n\n');
}

/**
 * Builds a CSS string from the provided component metadata and selector mapping.
 *
 * @param {Object} metadata - An object containing component metadata.
 * @param {Object} mapping - A mapping object to transform metadata into CSS selectors and properties.
 * @returns {string} The generated CSS string.
 */
export function buildComponentStyles(metadata, mapping) {
  const mappedStyles = mapMetadataToSelectors(metadata, mapping);
  const mergedStyles = mergeCSSRules(mappedStyles);
  return generateCSSString(mergedStyles);
}
