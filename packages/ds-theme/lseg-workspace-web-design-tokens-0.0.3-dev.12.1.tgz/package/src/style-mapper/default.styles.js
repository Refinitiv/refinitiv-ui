export default {
  selectorMapping: {},
};
