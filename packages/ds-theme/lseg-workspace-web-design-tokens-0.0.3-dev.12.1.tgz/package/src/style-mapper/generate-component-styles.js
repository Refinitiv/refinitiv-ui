import fg from 'fast-glob';
import pc from 'picocolors';
import { hideBin } from 'yargs/helpers';
import yargs from 'yargs/yargs';

import { buildComponentStyles } from './component-styles-builder.js';
import defaultStylesConfig from './default.styles.js';

import fsx from '../../../../scripts/fsx.js';

const argv = yargs(hideBin(process.argv))
  .usage('$0 [src]', 'Specify the source directory for configuration files', (yargs) => {
    yargs.positional('src', {
      describe: 'The source directory containing configuration files',
      type: 'string',
      default: 'src',
    });
  })
  .help().argv;

const STYLE_CONFIG_FILE_NAME_PATTERN = '**/*.styles.json';
const FILE_HEADER = `/* THIS FILE IS MACHINE GENERATED. DO NOT EDIT */\n`;
const FILE_CSS_HEADER = `import { css } from 'lit';\nexport default css\`\n`;
const OUTPUT_PATH = 'generated';
const OUTPUT_FILE_EXTENSION = '.styles.js';
const SOURCE_PATH = fsx.resolve(argv.src);
const COMPONENT_METADATA_PATH = fsx.resolve(
  '../../node_modules/@lseg-workspace/web-design-tokens/dist/metadata/component'
);

/**
 * Retrieves component styles metadata from metadata JSON file and builds CSS.
 * @param {object} configData - The mapping of selectors to styles.
 * @param {string} component - The name of the component.
 * @returns {string} The generated CSS for the component.
 */
const getComponentStyles = (configData, component) => {
  // Merge default configuration with component-specific configuration
  const mergedConfig = {
    ...defaultStylesConfig,
    ...configData,
    selectorMapping: {
      ...defaultStylesConfig.selectorMapping,
      ...configData.selectorMapping,
    },
    partsMapping: configData.partsMapping[component],
  };

  const componentMetadataFile = fsx.join(COMPONENT_METADATA_PATH, `${component}.json`);
  const metadata = fsx.readJson(componentMetadataFile);

  if (!metadata) {
    console.error(
      `\nMetadata for the ${component} component is missing. Please build web-design-token project or verify that the metadata file is provided.\n`
    );
    process.exit(1);
  }
  return buildComponentStyles(metadata, mergedConfig);
};

/**
 * Generates CSS files from configuration files found in the source directory.
 */
const generateCSS = () => {
  const stylesConfigFiles = fg.sync(STYLE_CONFIG_FILE_NAME_PATTERN, {
    cwd: SOURCE_PATH,
  });

  console.log(pc.bold(`🎨 Found ${pc.green(stylesConfigFiles.length)} component configs`));
  console.log(pc.bold(pc.blue('Starting to generate CSS files...')));

  stylesConfigFiles.forEach((configFile) => {
    const dirName = fsx.dirName(configFile);
    const componentName = fsx.baseName(configFile, true).replace('.styles', '');
    console.log(pc.blue(`Starting to generate CSS files for ${pc.green(componentName)} component`));

    const configData = fsx.readJson(fsx.join(SOURCE_PATH, configFile));
    let componentStyles = '';

    Object.keys(configData.partsMapping).forEach((component) => {
      const componentStyle = getComponentStyles(configData, component);
      componentStyles += componentStyle;
    });

    const content = `${FILE_HEADER}${FILE_CSS_HEADER}${componentStyles}\n\`;\n`;

    const filename = fsx.join(SOURCE_PATH, dirName, OUTPUT_PATH, `${componentName}${OUTPUT_FILE_EXTENSION}`);

    fsx.writeFile(filename, content);
  });

  console.log(pc.green('Finished without error'));
};

generateCSS();
